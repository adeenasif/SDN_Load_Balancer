# SDN Load Balancer - GUI

Run from this folder (Mininet needs root):

    sudo python3 gui_server.py                      # 3 servers + 4 clients (the proposal's topology)
    sudo python3 gui_server.py --servers 4 --clients 6

Open http://127.0.0.1:5000 . The script starts the controller (lb_controller.py), builds the Mininet
topology and serves the GUI. Use "Start traffic" in the page - no Mininet CLI needed.

If the controller cannot be auto-started (os-ken installed in a venv), use two terminals:

    osken-manager lb_controller.py
    sudo python3 gui_server.py --no-controller

Change the topology from the GUI: "Servers" / "Clients" sliders + "Apply topology" (max 10 hosts, e.g. 3+7 or 4+6).

Files
- lb_controller.py  controller (OS-Ken, OpenFlow 1.3) + REST API on :8080
- gui_server.py     Mininet + traffic driver (curl / iperf) + GUI server on :5000
- dashboard.html    the GUI
- topo.py           Mininet topology (build(n_servers, n_clients); defaults 3 / 4)
- smoke_test.py, test_lc.py, test_load.py   run WITHOUT the GUI running (start the controller yourself:
                    LB_ALGO=rr / lc / load osken-manager lb_controller.py)

Output: results.csv (experiment runs), assignments.csv (every connection assignment).
Old results.csv files are converted automatically (a copy is kept as results.csv.old).
